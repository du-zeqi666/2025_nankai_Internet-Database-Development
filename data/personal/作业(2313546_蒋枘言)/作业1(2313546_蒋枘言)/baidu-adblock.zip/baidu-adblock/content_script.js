// 百度极简去广告脚本

// 删除当前已有的广告
function removeAds() {
  // 去掉搜索结果中的“广告”标识及对应父元素
  document.querySelectorAll('span').forEach(el => {
    if (el.textContent.trim() === '广告') {
      const adItem = el.closest('.result') || el.closest('.c-container') || el.parentElement;
      if (adItem) adItem.remove();
    }
  });
}

// 初次执行
removeAds();

// 监听DOM变化，防止新广告加载进来
const observer = new MutationObserver(() => removeAds());
observer.observe(document.body, { childList: true, subtree: true });
