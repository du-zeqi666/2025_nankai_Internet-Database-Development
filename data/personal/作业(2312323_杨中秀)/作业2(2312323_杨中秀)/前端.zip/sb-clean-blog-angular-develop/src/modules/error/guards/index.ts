import { ErrorGuard } from './error.guard';

export const guards = [ErrorGuard];

export * from './error.guard';
