export interface Post {
    id: string;
    slug: string;
    backgroundImage: string;
    heading: string;
    subHeading: string;
    meta: string;
    body: string;
}
