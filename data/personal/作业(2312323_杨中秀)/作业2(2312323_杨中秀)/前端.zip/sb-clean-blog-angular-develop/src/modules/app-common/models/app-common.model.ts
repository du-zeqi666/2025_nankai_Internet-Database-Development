export interface Config {
    sbCleanBlogNodeURL: string;
    demoEnabled: boolean;
}
