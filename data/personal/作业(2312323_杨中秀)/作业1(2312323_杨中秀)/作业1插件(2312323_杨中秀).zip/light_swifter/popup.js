// 发送消息到内容脚本切换主题
function setTheme(theme) {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        chrome.scripting.executeScript({
            target: {tabId: tabs[0].id},
            func: (theme) => {
                // 应用主题
                const applyTheme = (theme) => {
                    const html = document.documentElement;
                    const body = document.body;
                    
                    // 清除之前的主题类
                    html.classList.remove('dark-theme', 'light-theme');
                    body.classList.remove('dark-theme', 'light-theme');
                    
                    // 存储原始样式
                    if (theme !== 'default' && !window.originalStyles) {
                        window.originalStyles = {
                            htmlBg: html.style.backgroundColor,
                            htmlColor: html.style.color,
                            bodyBg: body.style.backgroundColor,
                            bodyColor: body.style.color
                        };
                    }
                    
                    switch(theme) {
                        case 'dark':
                            html.classList.add('dark-theme');
                            body.classList.add('dark-theme');
                            html.style.backgroundColor = '#1a1a1a';
                            html.style.color = '#ffffff';
                            body.style.backgroundColor = '#1a1a1a';
                            body.style.color = '#ffffff';
                            break;
                        case 'light':
                            html.classList.add('light-theme');
                            body.classList.add('light-theme');
                            html.style.backgroundColor = '#ffffff';
                            html.style.color = '#000000';
                            body.style.backgroundColor = '#ffffff';
                            body.style.color = '#000000';
                            break;
                        default:
                            // 恢复原始样式
                            if (window.originalStyles) {
                                html.style.backgroundColor = window.originalStyles.htmlBg;
                                html.style.color = window.originalStyles.htmlColor;
                                body.style.backgroundColor = window.originalStyles.bodyBg;
                                body.style.color = window.originalStyles.bodyColor;
                            } else {
                                html.style.backgroundColor = '';
                                html.style.color = '';
                                body.style.backgroundColor = '';
                                body.style.color = '';
                            }
                    }
                    
                    // 处理链接颜色
                    document.querySelectorAll('a').forEach(link => {
                        if (theme === 'dark') {
                            link.style.color = '#61dafb';
                        } else if (theme === 'light') {
                            link.style.color = '#0000ee';
                        } else {
                            link.style.color = '';
                        }
                    });
                    
                    return theme;
                };
                
                return applyTheme(theme);
            },
            args: [theme]
        }).then((results) => {
            if (results && results[0]) {
                const currentTheme = results[0].result;
                updateStatus(currentTheme);
                
                // 保存当前主题偏好
                chrome.storage.sync.set({
                    [tabs[0].url]: currentTheme
                });
            }
        });
    });
}

// 更新状态显示
function updateStatus(theme) {
    const statusEl = document.getElementById('status');
    switch(theme) {
        case 'dark':
            statusEl.textContent = '当前: 暗色模式';
            break;
        case 'light':
            statusEl.textContent = '当前: 亮色模式';
            break;
        default:
            statusEl.textContent = '当前: 默认模式';
    }
}

// 页面加载时检查当前主题
document.addEventListener('DOMContentLoaded', () => {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        chrome.storage.sync.get([tabs[0].url], (result) => {
            const savedTheme = result[tabs[0].url];
            if (savedTheme) {
                updateStatus(savedTheme);
            }
        });
    });

    // 绑定按钮事件
    document.getElementById('lightMode').addEventListener('click', () => {
        setTheme('light');
    });
    
    document.getElementById('darkMode').addEventListener('click', () => {
        setTheme('dark');
    });
    
    document.getElementById('defaultMode').addEventListener('click', () => {
        setTheme('default');
    });
});
    