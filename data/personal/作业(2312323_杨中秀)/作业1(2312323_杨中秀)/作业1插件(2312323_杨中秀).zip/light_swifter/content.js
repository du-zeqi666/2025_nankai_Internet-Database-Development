// 页面加载时检查是否有保存的主题偏好
chrome.tabs.getCurrent(tab => {
    chrome.storage.sync.get([window.location.href], (result) => {
        const savedTheme = result[window.location.href];
        if (savedTheme) {
            applySavedTheme(savedTheme);
        }
    });
});

// 应用保存的主题
function applySavedTheme(theme) {
    const html = document.documentElement;
    const body = document.body;
    
    // 清除之前的主题类
    html.classList.remove('dark-theme', 'light-theme');
    body.classList.remove('dark-theme', 'light-theme');
    
    // 存储原始样式
    if (theme !== 'default' && !window.originalStyles) {
        window.originalStyles = {
            htmlBg: html.style.backgroundColor,
            htmlColor: html.style.color,
            bodyBg: body.style.backgroundColor,
            bodyColor: body.style.color
        };
    }
    
    switch(theme) {
        case 'dark':
            html.classList.add('dark-theme');
            body.classList.add('dark-theme');
            html.style.backgroundColor = '#1a1a1a';
            html.style.color = '#ffffff';
            body.style.backgroundColor = '#1a1a1a';
            body.style.color = '#ffffff';
            break;
        case 'light':
            html.classList.add('light-theme');
            body.classList.add('light-theme');
            html.style.backgroundColor = '#ffffff';
            html.style.color = '#000000';
            body.style.backgroundColor = '#ffffff';
            body.style.color = '#000000';
            break;
        default:
            // 恢复原始样式
            if (window.originalStyles) {
                html.style.backgroundColor = window.originalStyles.htmlBg;
                html.style.color = window.originalStyles.htmlColor;
                body.style.backgroundColor = window.originalStyles.bodyBg;
                body.style.color = window.originalStyles.bodyColor;
            }
    }
    
    // 处理链接颜色
    document.querySelectorAll('a').forEach(link => {
        if (theme === 'dark') {
            link.style.color = '#61dafb';
        } else if (theme === 'light') {
            link.style.color = '#0000ee';
        } else {
            link.style.color = '';
        }
    });
}
    