import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { FontLoader } from 'three/examples/jsm/loaders/FontLoader.js';
import { TextGeometry } from 'three/examples/jsm/geometries/TextGeometry.js';
import { GSAP } from 'gsap';
import EventBus, { EVENTS } from '../../core/events.js';
import { isMobile } from '../../core/utils.js';

/**
 * 3D Timeline Component
 * Renders a historical timeline in 3D space using Three.js
 */
export default class Timeline3D {
    constructor(containerId, data) {
        this.container = document.getElementById(containerId);
        this.data = data;
        
        if (!this.container) {
            console.error(`Timeline3D: Container #${containerId} not found`);
            return;
        }

        // Configuration
        this.config = {
            cameraZ: 100,
            nodeSpacing: 20,
            lineColor: 0xC41E3A, // Memorial Red
            nodeColor: 0xDAA520, // Victory Gold
            fogColor: 0x1A1A1A,  // Ink Black
            fontUrl: '/assets/fonts/helvetiker_regular.typeface.json'
        };

        // State
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.nodes = [];
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();
        this.isAnimating = false;

        this.init();
    }

    async init() {
        this.setupScene();
        this.setupLights();
        this.setupControls();
        await this.loadResources();
        this.createTimeline();
        this.addEventListeners();
        this.animate();
        
        EventBus.emit(EVENTS.LOADING_END);
    }

    setupScene() {
        // Scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(this.config.fogColor);
        this.scene.fog = new THREE.FogExp2(this.config.fogColor, 0.002);

        // Camera
        const aspect = this.container.clientWidth / this.container.clientHeight;
        this.camera = new THREE.PerspectiveCamera(60, aspect, 1, 1000);
        this.camera.position.set(0, 20, this.config.cameraZ);

        // Renderer
        this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        this.renderer.setPixelRatio(window.devicePixelRatio);
        this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
        this.renderer.shadowMap.enabled = true;
        this.container.appendChild(this.renderer.domElement);
    }

    setupLights() {
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
        this.scene.add(ambientLight);

        const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
        dirLight.position.set(10, 20, 10);
        dirLight.castShadow = true;
        this.scene.add(dirLight);

        // Spotlight for dramatic effect on active node
        this.spotLight = new THREE.SpotLight(0xC41E3A, 2);
        this.spotLight.position.set(0, 50, 0);
        this.spotLight.angle = Math.PI / 6;
        this.spotLight.penumbra = 1;
        this.scene.add(this.spotLight);
    }

    setupControls() {
        this.controls = new OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.05;
        this.controls.enableZoom = true;
        this.controls.maxPolarAngle = Math.PI / 2; // Don't go below ground
    }

    async loadResources() {
        const loader = new FontLoader();
        return new Promise((resolve) => {
            loader.load(this.config.fontUrl, (font) => {
                this.font = font;
                resolve();
            });
        });
    }

    createTimeline() {
        // 1. Create the main line (The Path of History)
        const points = [];
        const curve = new THREE.CatmullRomCurve3(
            this.data.map((_, i) => new THREE.Vector3(i * this.config.nodeSpacing, 0, 0))
        );
        
        const tubeGeometry = new THREE.TubeGeometry(curve, this.data.length * 10, 0.5, 8, false);
        const tubeMaterial = new THREE.MeshStandardMaterial({ 
            color: this.config.lineColor,
            roughness: 0.4,
            metalness: 0.6
        });
        const tube = new THREE.Mesh(tubeGeometry, tubeMaterial);
        this.scene.add(tube);

        // 2. Create Nodes (Events)
        this.data.forEach((event, index) => {
            const group = new THREE.Group();
            group.position.set(index * this.config.nodeSpacing, 0, 0);

            // Node Marker (Sphere)
            const geometry = new THREE.SphereGeometry(1.5, 32, 32);
            const material = new THREE.MeshStandardMaterial({ 
                color: this.config.nodeColor,
                emissive: 0x000000,
                roughness: 0.2,
                metalness: 0.8
            });
            const sphere = new THREE.Mesh(geometry, material);
            sphere.userData = { id: event.id, type: 'node' };
            group.add(sphere);

            // Year Label (3D Text)
            if (this.font) {
                const textGeo = new TextGeometry(event.year.toString(), {
                    font: this.font,
                    size: 2,
                    height: 0.2,
                });
                const textMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
                const textMesh = new THREE.Mesh(textGeo, textMat);
                textMesh.position.set(-2, 3, 0);
                group.add(textMesh);
            }

            // Base (Pedestal)
            const baseGeo = new THREE.CylinderGeometry(2, 2.5, 1, 32);
            const baseMat = new THREE.MeshStandardMaterial({ color: 0x333333 });
            const base = new THREE.Mesh(baseGeo, baseMat);
            base.position.y = -2;
            group.add(base);

            this.scene.add(group);
            this.nodes.push({ mesh: sphere, data: event, group: group });
        });
    }

    addEventListeners() {
        window.addEventListener('resize', this.onWindowResize.bind(this));
        this.renderer.domElement.addEventListener('mousemove', this.onMouseMove.bind(this));
        this.renderer.domElement.addEventListener('click', this.onClick.bind(this));
    }

    onWindowResize() {
        this.camera.aspect = this.container.clientWidth / this.container.clientHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    }

    onMouseMove(event) {
        // Calculate mouse position in normalized device coordinates
        const rect = this.renderer.domElement.getBoundingClientRect();
        this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

        // Raycasting for hover effect
        this.raycaster.setFromCamera(this.mouse, this.camera);
        const intersects = this.raycaster.intersectObjects(this.scene.children, true);

        if (intersects.length > 0) {
            const object = intersects[0].object;
            if (object.userData.type === 'node') {
                document.body.style.cursor = 'pointer';
                // Highlight effect
                object.material.emissive.setHex(0x550000);
            } else {
                document.body.style.cursor = 'default';
                this.resetNodeColors();
            }
        } else {
            document.body.style.cursor = 'default';
            this.resetNodeColors();
        }
    }

    onClick(event) {
        this.raycaster.setFromCamera(this.mouse, this.camera);
        const intersects = this.raycaster.intersectObjects(this.scene.children, true);

        if (intersects.length > 0) {
            const object = intersects[0].object;
            if (object.userData.type === 'node') {
                const nodeId = object.userData.id;
                this.focusNode(nodeId);
                EventBus.emit('timeline:select', this.nodes.find(n => n.data.id === nodeId).data);
            }
        }
    }

    resetNodeColors() {
        this.nodes.forEach(node => {
            node.mesh.material.emissive.setHex(0x000000);
        });
    }

    focusNode(id) {
        const targetNode = this.nodes.find(n => n.data.id === id);
        if (!targetNode) return;

        const targetPos = targetNode.group.position.clone();
        
        // Animate camera to look at the node
        GSAP.to(this.camera.position, {
            duration: 1.5,
            x: targetPos.x,
            y: targetPos.y + 10,
            z: targetPos.z + 30,
            ease: "power2.inOut",
            onUpdate: () => this.controls.update()
        });

        GSAP.to(this.controls.target, {
            duration: 1.5,
            x: targetPos.x,
            y: targetPos.y,
            z: targetPos.z,
            ease: "power2.inOut"
        });
    }

    animate() {
        requestAnimationFrame(this.animate.bind(this));
        this.controls.update();
        
        // Gentle floating animation for nodes
        const time = Date.now() * 0.001;
        this.nodes.forEach((node, i) => {
            node.group.position.y = Math.sin(time + i) * 0.5;
        });

        this.renderer.render(this.scene, this.camera);
    }
}
