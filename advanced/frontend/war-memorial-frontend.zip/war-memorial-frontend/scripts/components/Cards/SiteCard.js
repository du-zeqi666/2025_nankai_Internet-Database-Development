/**
 * 🏛️ Site Card Component
 * Displays memorial site info.
 */

import Component from '../Component';

export default class SiteCard extends Component {
    constructor(container, options = {}) {
        super(container, options);
    }
}
