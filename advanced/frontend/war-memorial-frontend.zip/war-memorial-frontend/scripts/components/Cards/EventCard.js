/**
 * 📅 Event Card Component
 * Displays historical event info for timeline.
 */

import Component from '../Component';

export default class EventCard extends Component {
    constructor(container, options = {}) {
        super(container, options);
    }
}
