/**
 * Hero Card Component
 * Handles interactions for hero cards
 */
export class HeroCard {
    constructor(selector) {
        this.cards = document.querySelectorAll(selector);
        this.init();
    }

    init() {
        this.cards.forEach(card => {
            card.addEventListener('mouseenter', this.onHover.bind(this));
            card.addEventListener('mouseleave', this.onLeave.bind(this));
        });
    }

    onHover(e) {
        const card = e.currentTarget;
        // Add any specific JS animation logic here if CSS isn't enough
        // For example, using GSAP
        if (typeof gsap !== 'undefined') {
            gsap.to(card, { scale: 1.05, duration: 0.3 });
        }
    }

    onLeave(e) {
        const card = e.currentTarget;
        if (typeof gsap !== 'undefined') {
            gsap.to(card, { scale: 1, duration: 0.3 });
        }
    }
}
