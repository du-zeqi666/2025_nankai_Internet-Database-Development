/**
 * 🏛️ 抗战胜利80周年纪念网站 - 核心应用入口
 * Core Application Entry Point
 * 
 * @version 1.0.0
 * @description 负责应用初始化、全局状态管理、错误捕获、性能监控及核心服务启动
 */

import '../../styles/main.scss';
import Router from './router';
import StateManager from './state';
import ApiService from './api';
import { initAnimations } from '../animations/gsap-config';
import { reportError, reportPerformance } from './utils';

class App {
    /**
     * 构造函数 - 初始化核心属性
     */
    constructor() {
        // 核心模块实例
        this.router = null;
        this.state = null;
        this.api = null;
        
        // 应用状态
        this.isInitialized = false;
        this.config = {
            debug: process.env.NODE_ENV === 'development',
            version: '1.0.0',
            apiBaseUrl: '/api/v1',
            theme: 'memorial', // 默认主题
            language: 'zh-CN'
        };

        // 性能指标存储
        this.metrics = {
            fcp: 0,
            lcp: 0,
            fid: 0,
            cls: 0,
            ttfb: 0
        };

        // 绑定上下文
        this.handleError = this.handleError.bind(this);
        this.handlePerformance = this.handlePerformance.bind(this);
        
        // 立即启动
        this.init();
    }

    /**
     * 初始化应用
     */
    async init() {
        console.group('🚀 Memorial App Initializing...');
        const startTime = performance.now();

        try {
            // 1. 注册全局错误处理
            this.registerErrorHandlers();

            // 2. 初始化状态管理
            this.state = new StateManager();
            await this.state.init();
            console.log('✅ State Manager Initialized');

            // 3. 初始化 API 服务
            this.api = new ApiService(this.config.apiBaseUrl);
            console.log('✅ API Service Initialized');

            // 4. 初始化路由
            this.router = new Router();
            console.log('✅ Router Initialized');

            // 5. 初始化动画引擎
            initAnimations();
            console.log('✅ Animation Engine Initialized');

            // 6. 绑定全局事件
            this.bindGlobalEvents();

            // 7. 初始化性能监控
            this.initPerformanceMonitoring();

            // 8. 检查设备能力
            this.checkDeviceCapabilities();

            // 9. 注册 Service Worker
            this.registerServiceWorker();

            // 标记初始化完成
            this.isInitialized = true;
            const endTime = performance.now();
            console.log(`✨ App Initialized in ${(endTime - startTime).toFixed(2)}ms`);

            // 触发应用就绪事件
            window.dispatchEvent(new CustomEvent('app:ready', {
                detail: { timestamp: Date.now() }
            }));

            // 处理初始路由
            this.router.handleCurrentRoute();

        } catch (error) {
            console.error('❌ App Initialization Failed:', error);
            this.handleCriticalError(error);
        } finally {
            console.groupEnd();
            this.removeLoader();
        }
    }

    /**
     * 注册全局错误处理
     */
    registerErrorHandlers() {
        // 捕获未处理的 Promise 拒绝
        window.addEventListener('unhandledrejection', (event) => {
            this.handleError(event.reason, 'Unhandled Rejection');
        });

        // 捕获常规 JS 错误
        window.addEventListener('error', (event) => {
            this.handleError(event.error, 'Global Error');
        });

        // 捕获资源加载错误
        window.addEventListener('error', (event) => {
            if (event.target && (event.target.tagName === 'IMG' || event.target.tagName === 'SCRIPT')) {
                console.warn(`⚠️ Resource Load Failed: ${event.target.src || event.target.href}`);
            }
        }, true);
    }

    /**
     * 统一错误处理
     * @param {Error} error 错误对象
     * @param {string} context 错误上下文
     */
    handleError(error, context = 'Unknown') {
        if (this.config.debug) {
            console.error(`[${context}]`, error);
        }

        // 上报错误
        reportError({
            message: error.message || String(error),
            stack: error.stack,
            context: context,
            url: window.location.href,
            timestamp: Date.now(),
            userAgent: navigator.userAgent
        });

        // 如果是严重错误，显示用户提示
        if (this.isCriticalError(error)) {
            this.showErrorToast('系统遇到问题，正在尝试恢复...');
        }
    }

    /**
     * 判断是否为严重错误
     */
    isCriticalError(error) {
        // 定义严重错误的条件
        return false; // 暂时返回 false
    }

    /**
     * 处理初始化阶段的严重错误
     */
    handleCriticalError(error) {
        const loader = document.getElementById('site-loader');
        if (loader) {
            loader.innerHTML = `
                <div class="error-screen">
                    <h1>启动失败</h1>
                    <p>抱歉，网站遇到严重问题无法启动。</p>
                    <button onclick="window.location.reload()">重试</button>
                </div>
            `;
        }
    }

    /**
     * 绑定全局事件
     */
    bindGlobalEvents() {
        // 监听网络状态
        window.addEventListener('online', () => this.handleNetworkChange(true));
        window.addEventListener('offline', () => this.handleNetworkChange(false));

        // 监听可见性变化
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') {
                this.handleAppResume();
            } else {
                this.handleAppPause();
            }
        });

        // 监听窗口大小变化 (防抖)
        let resizeTimeout;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => this.handleResize(), 200);
        });

        // 监听主题切换
        window.addEventListener('theme:change', (e) => {
            this.updateTheme(e.detail.theme);
        });
    }

    /**
     * 初始化性能监控 (Web Vitals)
     */
    initPerformanceMonitoring() {
        if ('performance' in window && 'PerformanceObserver' in window) {
            // 监控 LCP
            new PerformanceObserver((entryList) => {
                for (const entry of entryList.getEntries()) {
                    this.metrics.lcp = entry.startTime;
                    this.handlePerformance('LCP', entry.startTime);
                }
            }).observe({ type: 'largest-contentful-paint', buffered: true });

            // 监控 FID
            new PerformanceObserver((entryList) => {
                for (const entry of entryList.getEntries()) {
                    this.metrics.fid = entry.processingStart - entry.startTime;
                    this.handlePerformance('FID', this.metrics.fid);
                }
            }).observe({ type: 'first-input', buffered: true });

            // 监控 CLS
            new PerformanceObserver((entryList) => {
                for (const entry of entryList.getEntries()) {
                    if (!entry.hadRecentInput) {
                        this.metrics.cls += entry.value;
                        this.handlePerformance('CLS', this.metrics.cls);
                    }
                }
            }).observe({ type: 'layout-shift', buffered: true });
        }
    }

    /**
     * 处理性能数据
     */
    handlePerformance(metricName, value) {
        if (this.config.debug) {
            console.log(`📊 [Performance] ${metricName}:`, value);
        }
        
        // 上报性能数据
        reportPerformance({
            metric: metricName,
            value: value,
            page: window.location.pathname
        });
    }

    /**
     * 检查设备能力
     */
    checkDeviceCapabilities() {
        const html = document.documentElement;
        
        // 触摸支持
        if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
            html.classList.add('touch-device');
        } else {
            html.classList.add('no-touch');
        }

        // 减少动画请求
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            html.classList.add('reduce-motion');
            this.config.animationsEnabled = false;
        }

        // 深色模式偏好
        if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
            // 可以在这里自动切换主题
        }
    }

    /**
     * 注册 Service Worker
     */
    async registerServiceWorker() {
        if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
            try {
                const registration = await navigator.serviceWorker.register('/service-worker.js');
                console.log('✅ Service Worker Registered:', registration.scope);
                
                registration.addEventListener('updatefound', () => {
                    const newWorker = registration.installing;
                    newWorker.addEventListener('statechange', () => {
                        if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                            this.showUpdateNotification();
                        }
                    });
                });
            } catch (error) {
                console.error('❌ Service Worker Registration Failed:', error);
            }
        }
    }

    /**
     * 显示更新通知
     */
    showUpdateNotification() {
        // 实现 Toast 通知
        const toast = document.createElement('div');
        toast.className = 'update-toast';
        toast.innerHTML = `
            <p>网站有新版本可用</p>
            <button onclick="window.location.reload()">刷新更新</button>
        `;
        document.body.appendChild(toast);
    }

    /**
     * 处理网络状态变化
     */
    handleNetworkChange(isOnline) {
        if (isOnline) {
            document.body.classList.remove('is-offline');
            this.showToast('网络已连接', 'success');
            // 重新尝试失败的请求
            this.api.retryFailedRequests();
        } else {
            document.body.classList.add('is-offline');
            this.showToast('网络已断开，部分功能不可用', 'warning');
        }
    }

    /**
     * 应用恢复（从后台切回）
     */
    handleAppResume() {
        console.log('App Resumed');
        // 恢复动画、轮询等
        window.dispatchEvent(new CustomEvent('app:resume'));
    }

    /**
     * 应用暂停（切到后台）
     */
    handleAppPause() {
        console.log('App Paused');
        // 暂停动画、轮询等以节省资源
        window.dispatchEvent(new CustomEvent('app:pause'));
    }

    /**
     * 处理窗口大小调整
     */
    handleResize() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        
        // 更新 CSS 变量
        document.documentElement.style.setProperty('--vh', `${height * 0.01}px`);
        
        // 触发重排事件
        window.dispatchEvent(new CustomEvent('app:resize', {
            detail: { width, height }
        }));
    }

    /**
     * 更新主题
     */
    updateTheme(themeName) {
        document.documentElement.setAttribute('data-theme', themeName);
        localStorage.setItem('theme', themeName);
        this.config.theme = themeName;
    }

    /**
     * 移除加载动画
     */
    removeLoader() {
        const loader = document.getElementById('site-loader');
        if (loader) {
            loader.classList.add('fade-out');
            setTimeout(() => {
                loader.remove();
            }, 500);
        }
    }

    /**
     * 显示 Toast 消息 (简单实现，后续由 Toast 组件接管)
     */
    showToast(message, type = 'info') {
        // 触发全局 Toast 事件
        window.dispatchEvent(new CustomEvent('toast:show', {
            detail: { message, type }
        }));
    }
}

// 导出单例
const app = new App();
export default app;
